package apresentacao.telas;

import javax.swing.JPanel;

public class Configuracoes extends JPanel {
    public Configuracoes(){
        
    }
}
