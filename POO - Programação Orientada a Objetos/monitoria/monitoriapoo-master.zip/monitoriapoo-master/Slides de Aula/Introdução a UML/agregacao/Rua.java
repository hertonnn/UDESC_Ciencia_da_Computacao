package agregacao;

public class Rua{

    private List<Casa> casas;
    
}