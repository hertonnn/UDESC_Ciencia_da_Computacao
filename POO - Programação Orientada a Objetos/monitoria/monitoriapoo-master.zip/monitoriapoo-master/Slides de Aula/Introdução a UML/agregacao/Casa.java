package agregacao;

public class Casa{

    private int numero;

}