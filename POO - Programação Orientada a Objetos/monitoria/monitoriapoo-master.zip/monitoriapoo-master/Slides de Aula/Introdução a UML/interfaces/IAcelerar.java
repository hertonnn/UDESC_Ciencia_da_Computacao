package interfaces;

public interface IAcelerar{

    public void acelerar();
    
}
