package funcao;

public class Cidade{
    private String nome;
    private Pessoa[] habitantes;
}
