package funcao;

public class Pessoa{
    private String nome;
    private Cidade cidade;
}