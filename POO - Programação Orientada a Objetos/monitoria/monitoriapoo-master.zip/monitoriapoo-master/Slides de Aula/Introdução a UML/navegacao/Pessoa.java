package navegacao;

public class Pessoa{

    private List<Idioma> idiomas;
    
}