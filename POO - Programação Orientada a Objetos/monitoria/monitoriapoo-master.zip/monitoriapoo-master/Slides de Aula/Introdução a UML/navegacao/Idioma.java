package navegacao;

public class Idioma{

    private char[] alfabeto;

}