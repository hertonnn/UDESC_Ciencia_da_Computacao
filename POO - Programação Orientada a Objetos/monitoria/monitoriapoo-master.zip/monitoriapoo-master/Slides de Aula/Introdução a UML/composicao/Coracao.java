package composicao;

public class Coracao{

    public void bater(){
        System.out.println("Contraindo");
        System.out.println("Retraindo");
    }
    
}
