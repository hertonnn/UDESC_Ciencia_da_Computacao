package composicao;

public class Pessoa{

    private Coracao coracao;

    public Pessoa(Coracao coracao){
        this.coracao = coracao;
    }

}

