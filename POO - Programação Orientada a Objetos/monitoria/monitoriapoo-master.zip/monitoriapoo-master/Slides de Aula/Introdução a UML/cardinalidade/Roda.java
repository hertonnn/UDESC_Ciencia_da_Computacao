package cardinalidade;

public class Roda{

    private Carro carro;

}