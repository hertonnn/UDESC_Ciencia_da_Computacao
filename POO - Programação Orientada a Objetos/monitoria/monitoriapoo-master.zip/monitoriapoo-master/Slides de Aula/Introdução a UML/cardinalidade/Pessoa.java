package cardinalidade;

public class Pessoa{

    private List<Carro> carros;

}