package cardinalidade;

public class Carro{

    private Pessoa dono;
    private Roda[] rodas = new Roda[4];
    
}