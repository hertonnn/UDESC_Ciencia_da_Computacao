package dados;

public interface Cliente {

    public double calculaDespesa(int minutosUsados);

}