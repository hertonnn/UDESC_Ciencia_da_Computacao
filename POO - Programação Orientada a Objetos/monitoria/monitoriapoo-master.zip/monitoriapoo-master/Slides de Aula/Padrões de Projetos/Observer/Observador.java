
public interface Observador {

    public void atualizar(Object objeto);

}
