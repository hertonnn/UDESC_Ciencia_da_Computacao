
public class Moto extends Veiculo {

    private int numeroMarchas;
    private int numeroCilindradas;

    public int getNumeroMarchas() {
        return this.numeroMarchas;
    }

    public void setNumeroMarchas(int numeroMarchas) {
        this.numeroMarchas = numeroMarchas;
    }

    public int getNumeroCilindradas() {
        return this.numeroCilindradas;
    }

    public void setNumeroCilindradas(int numeroCilindradas) {
        this.numeroCilindradas = numeroCilindradas;
    }

}
