
public enum TipoVeiculo {

    CARRO, MOTO, BARCO, AVIAO;

}