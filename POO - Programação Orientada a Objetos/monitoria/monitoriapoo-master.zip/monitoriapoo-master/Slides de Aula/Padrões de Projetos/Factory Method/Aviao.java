
public class Aviao extends Veiculo {

    private double altitude;
    private int numeroJanelas;

    public double getAltitude() {
        return this.altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public int getNumeroJanelas() {
        return this.numeroJanelas;
    }

    public void setNumeroJanelas(int numeroJanelas) {
        this.numeroJanelas = numeroJanelas;
    }

}
