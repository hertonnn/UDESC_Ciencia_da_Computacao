
public class Barco extends Veiculo {

    private int numeroVelas;

    public int getNumeroVelas() {
        return this.numeroVelas;
    }

    public void setNumeroVelas(int numeroVelas) {
        this.numeroVelas = numeroVelas;
    }

}
