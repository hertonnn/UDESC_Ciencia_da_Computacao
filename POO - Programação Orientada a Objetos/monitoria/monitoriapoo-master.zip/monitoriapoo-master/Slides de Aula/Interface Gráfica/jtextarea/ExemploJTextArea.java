package jtextarea;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JTextArea;

public class ExemploJTextArea extends JPanel {

    public ExemploJTextArea() {
        JTextArea textArea = new JTextArea();
        add(textArea);
    }

}
