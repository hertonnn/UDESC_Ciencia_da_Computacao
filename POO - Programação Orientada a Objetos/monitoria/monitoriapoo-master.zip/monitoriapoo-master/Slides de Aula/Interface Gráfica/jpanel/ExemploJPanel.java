package jpanel;

import java.awt.Color;
import javax.swing.JPanel;

public class ExemploJPanel extends JPanel {

    public ExemploJPanel() {
        setBackground(Color.MAGENTA);

    }
}