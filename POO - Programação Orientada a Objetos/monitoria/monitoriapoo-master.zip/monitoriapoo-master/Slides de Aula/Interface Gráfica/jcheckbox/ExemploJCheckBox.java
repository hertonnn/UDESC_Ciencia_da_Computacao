package jcheckbox;

import javax.swing.JCheckBox;
import javax.swing.JPanel;

public class ExemploJCheckBox extends JPanel {

    public ExemploJCheckBox() {
        JCheckBox checkBox = new JCheckBox("Clique para selecionar");
        add(checkBox);
    }

}
