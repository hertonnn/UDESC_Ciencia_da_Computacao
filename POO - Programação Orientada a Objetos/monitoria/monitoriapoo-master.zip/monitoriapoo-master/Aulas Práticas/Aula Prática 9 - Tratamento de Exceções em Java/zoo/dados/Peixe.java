package dados;

public class Peixe extends Animal {

    private float temperaturaIdeal;

    public float getTemperaturaIdeal() {
        return this.temperaturaIdeal;
    }

    public void setTemperaturaIdeal(float temperaturaIdeal) {
        this.temperaturaIdeal = temperaturaIdeal;
    }

}