package dados;

public interface IOperacoesBasicas<T> {

    public T soma(T operador1, T operador2);

    public T subtracao(T operador1, T operador2);
}
