# SimuladorDeAp
Simulador de autômato com pilha desenvolvido em C.
